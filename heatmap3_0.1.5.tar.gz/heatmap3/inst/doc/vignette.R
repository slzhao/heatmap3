
## ----setting, echo=FALSE, cache=T----------------------------------------
options(width=58)


## ----data, tidy=T--------------------------------------------------------
set.seed(123456789)
rnormData<-matrix(rnorm(1000), 40, 25)
rnormData[1:15, seq(6, 25, 2)] = rnormData[1:15, seq(6, 25, 2)] + 2
rnormData[16:40, seq(7, 25, 2)] = rnormData[16:40, seq(7, 25, 2)] + 4
colnames(rnormData)<-c(paste("Control", 1:5, sep = ""), paste(c("TrtA", "TrtB"), rep(1:10,each=2), sep = ""))
rownames(rnormData)<-paste("Probe", 1:40, sep = "")
ColSideColors<-c(rep("steelblue2",5), rep(c("brown1", "mediumpurple2"),10))


## ----example1, tidy=T----------------------------------------------------
library(heatmap3)
heatmap3(rnormData,ColSideColors=ColSideColors,showRowDendro=F)


## ----example2, tidy=T----------------------------------------------------
ColSideColors<-cbind(Method1=c(rep("steelblue2",5), rep(c("lightgoldenrod"),20)),Method2=c(rep("steelblue2",5), rep(c("brown1", "mediumpurple2"),10)))
RowSideColors<-colorRampPalette(c("chartreuse4", "white", "firebrick"))(40)
heatmap3(rnormData,ColSideColors=ColSideColors,RowSideColors=RowSideColors,col=colorRampPalette(c("green", "black", "red"))(1024),ColAxisColors=1,RowAxisColors=1,legendfun=function() showLegend(legend=c("Control","Treatment","TrtA Treatment","TrtB Treatment"),col=c("steelblue2","lightgoldenrod","brown1","mediumpurple2")))


## ----showLegend, tidy=T, eval=T------------------------------------------
library(heatmap3)
showLegend


## ----showLegendExample, tidy=T,results='hide'----------------------------
example(showLegend)


